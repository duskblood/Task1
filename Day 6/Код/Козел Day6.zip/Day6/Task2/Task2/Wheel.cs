﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    internal class Wheel
    {
        public int Size { get; set; }

        public Wheel(int size)
        {
            Size = size;
        }
    }
}
